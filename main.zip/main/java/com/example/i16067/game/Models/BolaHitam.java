package com.example.i16067.game.Models;

public class BolaHitam extends Lingkaran {
    protected float x,y;
    protected int r;


    public BolaHitam(float x, float y, int r) {
        super(x, y, r);
    }

    public float getX() {
        return super.getX();
    }

    public float getY() {
        return super.getY();
    }

    public int getR() {
        return super.getR();
    }

    public void setX(float x) {
        super.setX(x);
    }

    public void setY(float y) {
        super.setY(y);
    }
}
